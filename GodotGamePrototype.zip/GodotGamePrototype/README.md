# Godot Game Prototype (Godot 4)

A clean starter project you can upload to GitHub as a portfolio sample.

## Features
- 2D player movement (WASD / Arrow Keys)
- Simple collision-ready player scene
- Main scene set as the startup scene

## How to Run
1. Install **Godot 4.x** (Standard).
2. Open Godot → **Import** → select this folder.
3. Click **Play** (▶).

## Next Ideas (quick wins)
- Add a tilemap level
- Add a camera that follows the player
- Add collectible items + score UI
- Add basic enemy AI that follows the player
